# config.py
import os
import boto3
import openai

OUTPUT_BUCKET = os.getenv("OUTPUT_BUCKET","calculat-docs-v2")
OUTPUT_PREFIX = os.getenv("OUTPUT_PREFIX", "extractions/")
OUTPUT_SNS_ARN = os.getenv("OUTPUT_SNS_ARN")
AWS_REGION = os.getenv("AWS_REGION")

OPENAI_ROUTER_KEY = os.getenv("OPENAI_ROUTER_KEY","")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "anthropic/claude-opus-4.6")

s3 = boto3.client("s3")
textract = boto3.client("textract")
sns = boto3.client("sns")
comprehend = boto3.client("comprehend")
translate = boto3.client("translate")

TRANSLATION_PROVIDER = os.getenv("TRANSLATION_PROVIDER", "aws")
TRANSLATE_TARGET_LANG = os.getenv("TRANSLATE_TARGET_LANG", "en")
TRANSLATE_SOURCE_LANG = os.getenv("TRANSLATE_SOURCE_LANG", "auto")

# OpenAI client
# if OPENAI_API_KEY:
#     openai.api_key = OPENAI_API_KEY
#     openai_client = openai
# else:
#     openai_client = None

