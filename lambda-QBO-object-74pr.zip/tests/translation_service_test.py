"""Tests for services.translation_service (lambda-QBO-object).

Run from the lambda-QBO-object/ directory or with PYTHONPATH set:
    cd lambda-QBO-object && pytest tests/translation_service_test.py -v

Because this lambda uses bare imports (from config import ...) and config.py
imports openai + boto3 clients, the tests stub sys.modules['config'] with a
fake before importing services.translation_service. This avoids any real AWS
or openai dependency in the test environment.
"""
import sys
import os
import copy
import unittest
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Ensure lambda-QBO-object/ is on sys.path for bare imports
# ---------------------------------------------------------------------------
_LAMBDA_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _LAMBDA_ROOT not in sys.path:
    sys.path.insert(0, _LAMBDA_ROOT)

# ---------------------------------------------------------------------------
# Install a fake 'config' module BEFORE translation_service is imported.
# This prevents config.py (which imports openai + boto3 clients) from running.
# ---------------------------------------------------------------------------
_fake_config = MagicMock()
_fake_config.TRANSLATION_PROVIDER = "aws"
_fake_config.TRANSLATE_TARGET_LANG = "en"
_fake_config.TRANSLATE_SOURCE_LANG = "auto"

# Install into sys.modules so `from config import ...` resolves to our fake.
sys.modules.setdefault("config", _fake_config)

# Now we can safely import the service (it will bind the fake config symbols).
import services.translation_service as ts


# ---------------------------------------------------------------------------
# Helpers to build fixture documents_json payloads
# ---------------------------------------------------------------------------

def _make_documents_json(
    summary: dict | None = None,
    items: list | None = None,
    adjustments: dict | None = None,
) -> dict:
    doc = {
        "summary": summary if summary is not None else {},
        "items": items if items is not None else [],
        "adjustments": adjustments if adjustments is not None else {},
    }
    return {"documents": [doc]}


# ---------------------------------------------------------------------------
# AC-1 / AC-7 — English (or empty/undetectable) is a true no-op
# ---------------------------------------------------------------------------

class TestEnglishNoOp(unittest.TestCase):
    """AC-1: English-primary document returns the SAME dict object unchanged.
    AC-7: Empty text / undetectable language also returns input unchanged.
    """

    def _make_comprehend_response(self, lang_code: str, score: float = 0.99) -> dict:
        return {"Languages": [{"LanguageCode": lang_code, "Score": score}]}

    def test_english_document_returns_same_object_no_translate_called(self):
        """AC-1: detect returns 'en'; translate.translate_text must never be called."""
        doc = _make_documents_json(
            summary={"PAYMENT_INFO": "Net 30 days", "DUE_DATE": "2024-01-15"},
            items=[{"ITEM": "Consulting", "AMOUNT": "1000.00"}],
        )
        mock_comp = MagicMock()
        mock_trans = MagicMock()
        mock_comp.detect_dominant_language.return_value = self._make_comprehend_response("en")

        with patch.object(ts, "comprehend", mock_comp), \
             patch.object(ts, "translate", mock_trans), \
             patch.object(ts, "TRANSLATION_PROVIDER", "aws"):
            result = ts.translate_documents_to_english(doc)

        self.assertIs(result, doc, "Must return the exact same dict object on English path")
        mock_trans.translate_text.assert_not_called()

    def test_empty_documents_returns_same_object(self):
        """AC-7: Empty documents_json has no translatable text; returns input unchanged."""
        doc = {"documents": []}
        mock_comp = MagicMock()
        mock_trans = MagicMock()
        mock_comp.detect_dominant_language.return_value = {"Languages": []}

        with patch.object(ts, "comprehend", mock_comp), \
             patch.object(ts, "translate", mock_trans), \
             patch.object(ts, "TRANSLATION_PROVIDER", "aws"):
            result = ts.translate_documents_to_english(doc)

        self.assertIs(result, doc)
        mock_trans.translate_text.assert_not_called()

    def test_undetectable_language_returns_input_unchanged(self):
        """AC-7: When detection returns no languages, treat as English -> no-op."""
        doc = _make_documents_json(summary={"NOTES": "???"})
        mock_comp = MagicMock()
        mock_trans = MagicMock()
        mock_comp.detect_dominant_language.return_value = {"Languages": []}

        with patch.object(ts, "comprehend", mock_comp), \
             patch.object(ts, "translate", mock_trans), \
             patch.object(ts, "TRANSLATION_PROVIDER", "aws"):
            result = ts.translate_documents_to_english(doc)

        self.assertIs(result, doc)
        mock_trans.translate_text.assert_not_called()


# ---------------------------------------------------------------------------
# AC-2 / AC-3 — Non-English: whitelisted fields translated, identifiers preserved
# ---------------------------------------------------------------------------

class TestNonEnglishTranslation(unittest.TestCase):
    """AC-2: Whitelisted free-text fields are translated for non-English documents.
    AC-3: Numeric/date/identifier fields are byte-identical after the call.
    """

    @staticmethod
    def _echo_translate(Text, SourceLanguageCode, TargetLanguageCode, **kwargs):
        """Fake translate: prepend 'EN:' so we can assert it was called."""
        return {"TranslatedText": "EN:" + Text}

    def test_whitelisted_summary_and_item_fields_translated(self):
        """AC-2: PAYMENT_INFO and items ITEM/DESCRIPTION are translated for French doc."""
        doc = _make_documents_json(
            summary={
                "PAYMENT_INFO": "Paiement à 30 jours",
                "PAYMENT_TERMS": "Net 30",
                "DUE_DATE": "2024-01-15",
                "VENDOR_EMAIL": "vendor@example.fr",
                "TOTAL": "1500.00",
                "CURRENCY": "EUR",
            },
            items=[{
                "ITEM": "Services de conseil",
                "DESCRIPTION": "Conseil en stratégie",
                "AMOUNT": "500.00",
                "PRICE": "250.00",
                "QUANTITY": "2",
                "EXPENSE_ROW": "Services de conseil 500.00 EUR",
            }],
            adjustments={"tax": [{"label": "TVA", "amount": "100.00"}]},
        )
        original_due_date = doc["documents"][0]["summary"]["DUE_DATE"]
        original_email = doc["documents"][0]["summary"]["VENDOR_EMAIL"]
        original_total = doc["documents"][0]["summary"]["TOTAL"]
        original_currency = doc["documents"][0]["summary"]["CURRENCY"]
        original_amount = doc["documents"][0]["items"][0]["AMOUNT"]
        original_price = doc["documents"][0]["items"][0]["PRICE"]
        original_quantity = doc["documents"][0]["items"][0]["QUANTITY"]
        original_expense_row = doc["documents"][0]["items"][0]["EXPENSE_ROW"]
        original_adjustments = copy.deepcopy(doc["documents"][0]["adjustments"])

        mock_comp = MagicMock()
        mock_trans = MagicMock()
        mock_comp.detect_dominant_language.return_value = {
            "Languages": [{"LanguageCode": "fr", "Score": 0.97}]
        }
        mock_trans.translate_text.side_effect = self._echo_translate

        with patch.object(ts, "comprehend", mock_comp), \
             patch.object(ts, "translate", mock_trans), \
             patch.object(ts, "TRANSLATION_PROVIDER", "aws"):
            result = ts.translate_documents_to_english(doc)

        summary = result["documents"][0]["summary"]
        items = result["documents"][0]["items"]

        # Whitelisted summary fields — translated
        self.assertTrue(
            summary["PAYMENT_INFO"].startswith("EN:"),
            "PAYMENT_INFO should be translated",
        )
        self.assertTrue(
            summary["PAYMENT_TERMS"].startswith("EN:"),
            "PAYMENT_TERMS should be translated",
        )

        # Whitelisted item fields — translated
        self.assertTrue(items[0]["ITEM"].startswith("EN:"), "ITEM should be translated")
        self.assertTrue(
            items[0]["DESCRIPTION"].startswith("EN:"), "DESCRIPTION should be translated"
        )

        # AC-3: identifiers / dates / numbers — BYTE IDENTICAL
        self.assertEqual(summary["DUE_DATE"], original_due_date, "DUE_DATE must not change")
        self.assertEqual(summary["VENDOR_EMAIL"], original_email, "VENDOR_EMAIL must not change")
        self.assertEqual(summary["TOTAL"], original_total, "TOTAL must not change")
        self.assertEqual(summary["CURRENCY"], original_currency, "CURRENCY must not change")
        self.assertEqual(items[0]["AMOUNT"], original_amount, "AMOUNT must not change")
        self.assertEqual(items[0]["PRICE"], original_price, "PRICE must not change")
        self.assertEqual(items[0]["QUANTITY"], original_quantity, "QUANTITY must not change")
        self.assertEqual(
            items[0]["EXPENSE_ROW"], original_expense_row, "EXPENSE_ROW must not change"
        )
        # Adjustments block must be verbatim
        self.assertEqual(
            result["documents"][0]["adjustments"],
            original_adjustments,
            "adjustments block must not be touched",
        )

    def test_prefix_matched_summary_key_translated(self):
        """AC-3 / unique_key suffix: PAYMENT_INFO_2 matches the PAYMENT_INFO prefix."""
        doc = _make_documents_json(
            summary={"PAYMENT_INFO_2": "Informations de paiement supplémentaires"},
        )
        mock_comp = MagicMock()
        mock_trans = MagicMock()
        mock_comp.detect_dominant_language.return_value = {
            "Languages": [{"LanguageCode": "fr", "Score": 0.95}]
        }
        mock_trans.translate_text.side_effect = self._echo_translate

        with patch.object(ts, "comprehend", mock_comp), \
             patch.object(ts, "translate", mock_trans), \
             patch.object(ts, "TRANSLATION_PROVIDER", "aws"):
            result = ts.translate_documents_to_english(doc)

        self.assertTrue(
            result["documents"][0]["summary"]["PAYMENT_INFO_2"].startswith("EN:"),
            "Prefix-matched key PAYMENT_INFO_2 should be translated",
        )


# ---------------------------------------------------------------------------
# AC-5 — Kill switch: TRANSLATION_PROVIDER=none
# ---------------------------------------------------------------------------

class TestKillSwitch(unittest.TestCase):
    """AC-5: When TRANSLATION_PROVIDER != 'aws', entire step is skipped."""

    def test_provider_none_returns_input_unchanged_no_clients_called(self):
        """AC-5: TRANSLATION_PROVIDER='none' -> returns same object, no boto3 calls."""
        doc = _make_documents_json(summary={"PAYMENT_INFO": "Paiement 30 jours"})
        mock_comp = MagicMock()
        mock_trans = MagicMock()

        with patch.object(ts, "comprehend", mock_comp), \
             patch.object(ts, "translate", mock_trans), \
             patch.object(ts, "TRANSLATION_PROVIDER", "none"):
            result = ts.translate_documents_to_english(doc)

        self.assertIs(result, doc)
        mock_comp.detect_dominant_language.assert_not_called()
        mock_trans.translate_text.assert_not_called()


# ---------------------------------------------------------------------------
# AC-6 — Provider failure fallback
# ---------------------------------------------------------------------------

class TestProviderFailureFallback(unittest.TestCase):
    """AC-6: Detection or translation failures fall back to the original dict without raising."""

    def test_detect_raises_returns_original_no_exception(self):
        """AC-6: detect_dominant_language raises -> original dict returned, no exception."""
        doc = _make_documents_json(summary={"NOTES": "Remarques importantes"})
        mock_comp = MagicMock()
        mock_comp.detect_dominant_language.side_effect = Exception("Comprehend unavailable")

        with patch.object(ts, "comprehend", mock_comp), \
             patch.object(ts, "TRANSLATION_PROVIDER", "aws"):
            result = ts.translate_documents_to_english(doc)

        self.assertIs(result, doc)

    def test_translate_raises_returns_original_no_exception(self):
        """AC-6: translate_text raises -> original dict returned, no exception propagated."""
        doc = _make_documents_json(
            summary={"PAYMENT_INFO": "Paiement à 30 jours"},
            items=[{"ITEM": "Service"}],
        )
        mock_comp = MagicMock()
        mock_trans = MagicMock()
        mock_comp.detect_dominant_language.return_value = {
            "Languages": [{"LanguageCode": "fr", "Score": 0.98}]
        }
        mock_trans.translate_text.side_effect = Exception("Translate throttled")

        with patch.object(ts, "comprehend", mock_comp), \
             patch.object(ts, "translate", mock_trans), \
             patch.object(ts, "TRANSLATION_PROVIDER", "aws"):
            result = ts.translate_documents_to_english(doc)

        self.assertIs(result, doc)

    def test_no_partial_mutation_on_translate_failure(self):
        """AC-6: A translate failure mid-way must not leave partially mutated data visible.

        Because we deep-copy before translating and only return the working copy
        on full success (falling back to the original on any exception), the
        original is always intact on failure.
        """
        original_payment_info = "Paiement à 30 jours"
        original_item = "Service de conseil"
        doc = _make_documents_json(
            summary={"PAYMENT_INFO": original_payment_info},
            items=[{"ITEM": original_item}],
        )

        call_count = 0

        def translate_fails_on_second(Text, SourceLanguageCode, TargetLanguageCode, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count >= 2:
                raise Exception("Translate error on second call")
            return {"TranslatedText": "EN:" + Text}

        mock_comp = MagicMock()
        mock_trans = MagicMock()
        mock_comp.detect_dominant_language.return_value = {
            "Languages": [{"LanguageCode": "fr", "Score": 0.98}]
        }
        mock_trans.translate_text.side_effect = translate_fails_on_second

        with patch.object(ts, "comprehend", mock_comp), \
             patch.object(ts, "translate", mock_trans), \
             patch.object(ts, "TRANSLATION_PROVIDER", "aws"):
            result = ts.translate_documents_to_english(doc)

        # The result must be the original unchanged (returned on outer try/except)
        self.assertIs(result, doc)
        # Fields must remain at original values (the deep-copy absorbed the partial work)
        self.assertEqual(result["documents"][0]["summary"]["PAYMENT_INFO"], original_payment_info)
        self.assertEqual(result["documents"][0]["items"][0]["ITEM"], original_item)


if __name__ == "__main__":
    unittest.main()
