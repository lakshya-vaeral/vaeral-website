# handlers/invoice_handler.py
import asyncio
import time
from typing import Any, Dict, List, Optional
from services.db_service import update_attachment_state
import boto3
import os
import json
from services.sns_parser import parse_sns_event
from services.textract_service import (
    run_analyze_expense,
    run_analyze_document_all,
    analyze_expense_to_documents,
    extract_query_answers,      
    normalize_email, 
    extract_payment_footer_from_lines           
)
from services.textract_service import (
    extract_rows_from_tables,
    extract_adjustments_from_rows,
    recover_missing_line_items_from_rows
)
from services.openai_service import create_qbo_bill_with_openai
from services.translation_service import translate_documents_to_english
from utils.common import now_iso,write_result, maybe_publish_to_sns
sqs = boto3.client("sqs")

FULFILLMENT_JOB_QUEUE_URL = os.environ["FULFILLMENT_JOB_QUEUE_URL"]



def _nl_line(label: str, v: str) -> str:
    v = (v or "").strip()
    return f"{label}: {v}" if v else ""

def _sanitize_payment_method(payment_method: str, payment_terms: str) -> str:
    method = (payment_method or "").strip()
    terms = (payment_terms or "").strip()
    if not method:
        return ""
    if terms and method.lower() == terms.lower():
        return "" 
    return method

def get_payment_infor(answers:Dict[str, str]):
    payment_info_lines = [
        _nl_line("Payment Method", answers.get("PAYMENT_METHOD")),
        _nl_line("Bank Name", answers.get("BANK_NAME")),
        _nl_line("Beneficiary Name", answers.get("BENEFICIARY_NAME")),
        _nl_line("Account Number", answers.get("ACCOUNT_NUMBER")),
        _nl_line("IBAN", answers.get("IBAN")),
        _nl_line("SWIFT/BIC", answers.get("SWIFT_BIC")),
        _nl_line("IFSC/MICR", answers.get("IFSC_MICR")),
        _nl_line("Routing / Sort Code", answers.get("ROUTING_SORT_CODE")),
        _nl_line("Payment Reference", answers.get("PAYMENT_REFERENCE")),
        _nl_line("Remit-To Address", answers.get("REMIT_TO_ADDRESS")),
        _nl_line("Remittance Instructions", answers.get("REMITTANCE_INSTRUCTIONS")),
    ]
    payment_info = "\n".join([x for x in payment_info_lines if x])
    if payment_info:
        return payment_info
    return ""



async def analyze_textract_for_file(bucket: str, key: str) -> Dict[str, Any]:
    """Run AnalyzeExpense and optional AnalyzeDocument; hide async-to-thread detail."""
    expense_resp = await asyncio.to_thread(run_analyze_expense, bucket, key)
    document_resp = await asyncio.to_thread(run_analyze_document_all, bucket, key)

    return {
        "analyze_expense": expense_resp,
        "analyze_document": document_resp,
    }
    

async def _process_target(t: Dict[str, str]) -> Dict[str, Any]:
    start_time = time.time()
    bucket, s3_key = t["bucket"], t["key"]
    print(f"[PROCESS] s3://{bucket}/{s3_key}")
    tracking_id = s3_key.split("/", 1)[0]

    # 1) Run Textract
    textract_data = await analyze_textract_for_file(bucket, s3_key)
    expense_resp = textract_data.get("analyze_expense")

    # 2) Convert AnalyzeExpense -> your clean documents[] JSON
    documents_json = analyze_expense_to_documents(expense_resp)

    document_resp = textract_data.get("analyze_document")

    if document_resp and documents_json.get("documents"):
        blocks = document_resp.get("Blocks", [])
        # 1️⃣ Rebuild table rows from TABLE structure
        table_rows = extract_rows_from_tables(blocks)
        # 2️⃣ Extract adjustments from reconstructed rows
        table_adjustments = extract_adjustments_from_rows(table_rows)
        # 3️⃣ Merge into existing adjustments
        doc = documents_json["documents"][0]
        existing_adjustments = doc.get("adjustments", {
            "tax": [],
            "discount": [],
            "shipping": []
        })
        for key in ["tax", "discount", "shipping"]:
            existing_adjustments[key].extend(
                table_adjustments.get(key, [])
            )

        doc["adjustments"] = existing_adjustments
        recovered_items = recover_missing_line_items_from_rows(
            table_rows,
            doc.get("items", []),
            doc.get("summary", {})
        )

        if recovered_items:
            doc.setdefault("items", []).extend(recovered_items)




    if document_resp:
        answers = extract_query_answers(document_resp)
        footer_payment = extract_payment_footer_from_lines(document_resp.get("Blocks", []))

        vendor_email = normalize_email(answers.get("VENDOR_EMAIL", ""))
        payment_terms=answers.get("PAYMENT_TERMS","")
        raw_payment_method = answers.get("PAYMENT_METHOD", "")
        payment_method=_sanitize_payment_method(answers.get("PAYMENT_METHOD", ""), payment_terms)
        print(f"[PAYMENT_METHOD] raw={raw_payment_method!r}, terms={payment_terms!r}, sanitized={payment_method!r}")
        answers["PAYMENT_METHOD"] = payment_method
        payment_info=get_payment_infor(answers)
        
        if not payment_terms:
            payment_terms = footer_payment.get("PAYMENT_TERMS", "")
        if not payment_info:
            payment_info = footer_payment.get("PAYMENT_INFO", "")

        vendor_address=answers.get("VENDOR_ADDRESS","")
        due_date=answers.get("DUE_DATE","")
        discount=answers.get("DISCOUNT", "")
        taxes=answers.get("TAXES","")
        if documents_json.get("documents"):
            documents_json["documents"][0]["summary"]["PAYMENT_INFO"]=payment_info
            if vendor_email:
                documents_json["documents"][0]["summary"]["VENDOR_EMAIL"] = vendor_email
            documents_json["documents"][0]["summary"]["DUE_DATE"] = due_date
            if vendor_address:
                documents_json["documents"][0]["summary"]["VENDOR_ADDRESS"] = vendor_address
            if not documents_json["documents"][0]["summary"].get("PAYMENT_TERMS") and payment_terms:
                documents_json["documents"][0]["summary"]["PAYMENT_TERMS"] = payment_terms
            if not documents_json["documents"][0]["summary"].get("PAYMENT_INFO") and payment_method:
                documents_json["documents"][0]["summary"]["PAYMENT_INFO"] = payment_method
            if not documents_json["documents"][0]["summary"].get("DISCOUNT") and discount:
                documents_json["documents"][0]["summary"]["DISCOUNT"] = discount
            if not documents_json["documents"][0]["summary"].get("TAXES") and taxes:
                documents_json["documents"][0]["summary"]["TAXES"] = taxes
            
           

    documents_json = translate_documents_to_english(documents_json)
    documents_list = documents_json.get("documents", []) or []
    print("document json",documents_json)
    print("document list", documents_list)
    # 3) Call OpenAI ONCE for the whole PDF (all pages together)
    file_meta = {"bucket": bucket, "key": s3_key}
    print(f"[PROCESS] Creating SINGLE QBO bill for entire file (pages={len(documents_list)})")

    # IMPORTANT: pass the WHOLE documents_json (not each page) here
    qbo_bill = await create_qbo_bill_with_openai(documents_json, file_meta,tracking_id=tracking_id)

    # 4) Build final payload (one bill per file)
    result_payload = {
        "source": "textract_documents",
        "file": file_meta,
        "extracted_at": now_iso(),    
        "documents": documents_list,   
        "qbo_bill": qbo_bill,         
        # "textract_raw": textract_data,   #debugging the extracted data
    }

    out_uri = await asyncio.to_thread(write_result, bucket, s3_key, result_payload)
    result_payload["output_uri"] = out_uri
    await asyncio.to_thread(maybe_publish_to_sns, result_payload)

    end_time = time.time()
    print(f"Persisted result to {out_uri}")
    print(f"Processed s3://{bucket}/{s3_key} in {end_time - start_time:.2f} seconds")
    update_attachment_state(tracking_id,out_uri)
    body = {
        "trackingId": tracking_id,
        "source": "Attachment",
    }
    resp = sqs.send_message(
        QueueUrl=FULFILLMENT_JOB_QUEUE_URL,
        MessageBody=json.dumps(body),
    )
    print(f"[SQS] Sent state-change for {tracking_id}, MessageId={resp['MessageId']}")

    return {
        "s3": f"s3://{bucket}/{s3_key}",
        "output": out_uri,
        "bill_created": qbo_bill is not None,
        "num_documents": len(documents_list),          # how many pages/ExpenseDocuments
        "num_bills": 1 if qbo_bill is not None else 0  # always 0 or 1
    }



