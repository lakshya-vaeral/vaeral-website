import json
import re
import os
from datetime import datetime
from typing import Any, Dict
from config import OUTPUT_BUCKET, OUTPUT_PREFIX, OUTPUT_SNS_ARN,s3,sns


def json_dumps(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, default=str)

def safe_key_part(s: str) -> str:
    s = s.replace(" ", "_")
    return re.sub(r"[^A-Za-z0-9_\-\.\/]+", "", s)

def now_iso() -> str:
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

def is_pdf(key: str) -> bool:
    return key.lower().endswith(".pdf")

def unique_key(target: Dict[str, Any], base: str) -> str:
    """
    Ensure key is unique inside target dict.
    If 'OTHER' already exists, next will be 'OTHER_2', then 'OTHER_3', etc.
    """
    key = base
    if key not in target:
        return key
    i = 2
    while f"{base}_{i}" in target:
        i += 1
    return f"{base}_{i}"

def write_result(bucket: str, key: str, result: Dict[str, Any]) -> str:
    """
    Given an input key like:
      test-123/attachments/input/5.1 - Maizon Dort Emails.pdf

    Write result JSON to the parallel path:
      test-123/attachments/extracted/5.1 - Maizon Dort Emails.json
    """
    # Directory part, e.g. "test-123/attachments/input"
    dir_name = os.path.dirname(key)
    # File name, e.g. "input.pdf"
    filename = os.path.basename(key)

    # Replace ".../input" with ".../extracted"
    # so "test-123/attachments/input" -> "test-123/attachments/extracted"
    if dir_name.endswith("/input"):
        extracted_dir = dir_name.rsplit("/", 1)[0] + "/extracted"
    else:
        # Fallback: just append "extracted" next to the existing dir
        extracted_dir = dir_name + "/extracted"

    # Strip extension: "input"
    base_no_ext = os.path.splitext(filename)[0]
    # Make it safe for S3 key
    base_filename = safe_key_part(base_no_ext)

    # Final output key
    output_key = f"{extracted_dir}/{base_filename}.json"

    body = json_dumps(result).encode("utf-8")
    s3.put_object(
        Bucket=bucket,
        Key=output_key,
        Body=body,
        ContentType="application/json",
    )
    print(f"Saved result to s3://{bucket}/{output_key}")
    return f"s3://{bucket}/{output_key}"

def maybe_publish_to_sns(result: Dict[str, Any]):
    if not OUTPUT_SNS_ARN:
        return
    sns.publish(
        TopicArn=OUTPUT_SNS_ARN,
        Message=_json_dumps(result),
        Subject="TextractExtractionReady",
    )


