import asyncio
from utils.invoice_handler import _process_target
from services.sns_parser import parse_sns_event   # (kept for backwards compatibility, but not used)
from utils.common import json_dumps


async def _lambda_handler_async(event, context):
    print("[ATTACHMENT EVENT]", json_dumps(event))

    # =============================================================
    # MODE 1 → Step Functions Mode
    # =============================================================
    # Step Functions always sends:
    # { "trackingId": "...", "bucket": "...", "key": "..." }
    if isinstance(event, dict) and "bucket" in event and "key" in event:
        tracking_id = event.get("trackingId")
        bucket = event["bucket"]
        key = event["key"]

        # Skip folder marker prefixes like: "123456/attachments/input/"
        if key.endswith("/"):
            print(f"[StepFunctions] Skipping folder marker key: {key}")
            return {
                "trackingId": tracking_id,
                "sourceBucket": bucket,
                "sourceKey": key,
                "status": "skipped-folder-marker"
            }

        print(f"[StepFunctions] Processing attachment: s3://{bucket}/{key}")

        # Build target exactly as _process_target expects
        target = {
            "bucket": bucket,
            "key": key,
        }
        if tracking_id:
            target["trackingId"] = tracking_id

        # Your existing extraction logic
        result = await _process_target(target)

        # Clean Step Functions response format
        return {
            "trackingId": tracking_id,
            "sourceBucket": bucket,
            "sourceKey": key,
            "processed": result,    
            "status": "OK"
        }

    # =============================================================
    # MODE 2 → Legacy SNS/SQS Mode 
    # =============================================================
    print("[Legacy SNS] Parsing SNS event...")
    targets = parse_sns_event(event)
    if not targets:
        print("No S3 records found in SNS event.")
        return {"status": "no_s3_records_found"}

    # Process all targets concurrently
    tasks = [_process_target(t) for t in targets]
    processed = await asyncio.gather(*tasks, return_exceptions=False)

    return {
        "status": "ok",
        "processed": processed,
    }


def lambda_handler(event, context):
    return asyncio.run(_lambda_handler_async(event, context))
