# services/textract_service.py
import time
from typing import Any, Dict, List, Optional
import json
import botocore

from config import textract
from utils.common import is_pdf, unique_key
import re
import boto3

s3 = boto3.client("s3")
# ----------- AnalyzeExpense -> documents (summary/items) -----------

def _build_summary_map(exp_doc: Dict[str, Any]) -> Dict[str, str]:
    summary: Dict[str, str] = {}

    for sf in exp_doc.get("SummaryFields", []) or []:
        type_obj = sf.get("Type") or {}
        label_obj = sf.get("LabelDetection") or {}
        value_obj = sf.get("ValueDetection") or {}

        value = value_obj.get("Text")
        if not value:
            continue

        type_text = type_obj.get("Text")
        label_text = label_obj.get("Text")

        print("type_text",type_text,"label_text",label_text)

        if type_text:
            key = type_text.upper()
        elif label_text:
            key = label_text.strip().upper().replace(" ", "_")
        else:
            key = "OTHER"

        print("key", key)
        if key in summary and summary[key] != value:
            key = unique_key(summary, key)

        summary[key] = value

    return summary


def _build_items_list(exp_doc: Dict[str, Any]) -> List[Dict[str, str]]:
    items: List[Dict[str, str]] = []

    for group in exp_doc.get("LineItemGroups", []) or []:
        for li in group.get("LineItems", []) or []:
            print(f"[LINE ITEM] extracted {li}")
            fields = li.get("LineItemExpenseFields", []) or []
            item: Dict[str, str] = {}
            row_values: List[str] = []

            for f in fields:
                type_obj = f.get("Type") or {}
                label_obj = f.get("LabelDetection") or {}
                value_obj = f.get("ValueDetection") or {}

                value = value_obj.get("Text")
                if not value:
                    continue

                type_text = type_obj.get("Text")
                label_text = label_obj.get("Text")

                if type_text and type_text != "OTHER":
                    key = type_text.upper()
                elif label_text:
                    key = label_text.strip().upper().replace(" ", "_")
                else:
                    key = "OTHER"

                if key in item and item[key] != value:
                    key = unique_key(item, key)

                item[key] = value
                row_values.append(value)

            if item:
                if row_values:
                    item.setdefault("EXPENSE_ROW", " ".join(row_values))
                items.append(item)

    return items


def analyze_expense_to_documents(expense_resp: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Convert full Textract AnalyzeExpense response into:
    { "documents": [ { "summary": {...}, "items": [...] }, ... ] }
    """
    docs_out: List[Dict[str, Any]] = []

    if not expense_resp:
        return {"documents": docs_out}

    for exp_doc in expense_resp.get("ExpenseDocuments", []) or []:
        summary = _build_summary_map(exp_doc)
        items = _build_items_list(exp_doc)

        docs_out.append({
            "summary": summary,
            "items": items
        })

    return {"documents": docs_out}

# ----------- Textract AnalyzeExpense & AnalyzeDocument -----------

def _drain_expense_job(job_id: str) -> Optional[List[Dict[str, Any]]]:
    docs: List[Dict[str, Any]] = []
    next_token: Optional[str] = None
    tries = 0
    max_tries = 30

    while True:
        tries += 1
        kwargs: Dict[str, Any] = {"JobId": job_id}
        if next_token:
            kwargs["NextToken"] = next_token

        resp = textract.get_expense_analysis(**kwargs)
        status = resp.get("JobStatus", "IN_PROGRESS")
        print(f"[GetExpenseAnalysis] status={status}, docs={len(resp.get('ExpenseDocuments', []))}")

        if "ExpenseDocuments" in resp:
            docs.extend(resp["ExpenseDocuments"])

        next_token = resp.get("NextToken")

        if status == "FAILED":
            print(f"[GetExpenseAnalysis] FAILED job {job_id}")
            return None

        if status in ("SUCCEEDED", "PARTIAL_SUCCESS") and not next_token:
            break

        if tries >= max_tries:
            print("[GetExpenseAnalysis] max polling attempts reached")
            return None

        time.sleep(1)

    return docs


def run_analyze_expense(bucket: str, key: str) -> Optional[Dict[str, Any]]:
    doc_spec = {"S3Object": {"Bucket": bucket, "Name": key}}

    try:
        # if is_pdf(key) or key.lower().endswith((".tif", ".tiff")):
        print(f"[AnalyzeExpense-ASYNC] StartExpenseAnalysis for: s3://{bucket}/{key}")
        start = textract.start_expense_analysis(DocumentLocation=doc_spec)
        job_id = start["JobId"]
        print(f"[AnalyzeExpense-ASYNC] JobId={job_id}")
        docs = _drain_expense_job(job_id)
        if not docs:
            print("[AnalyzeExpense-ASYNC] No ExpenseDocuments")
            return None

        print(
            "[RAW_EXPENSE_ANALYZER_OUTPUT]",
            json.dumps(
                {
                    "JobId": job_id,
                    "ExpenseDocuments": docs
                },
                indent=2,
                default=str
            )
        )

        return {"JobId": job_id, "ExpenseDocuments": docs}

        print(f"[AnalyzeExpense-SYNC] analyze_expense for: s3://{bucket}/{key}")
        resp = textract.analyze_expense(Document=doc_spec)
        if resp.get("ExpenseDocuments"):
            print(f"[AnalyzeExpense-SYNC] got {len(resp['ExpenseDocuments'])} ExpenseDocuments")
            print(f"[AnalyzeExpense-SYNC] Response formed : {resp}")
            return resp
        print("[AnalyzeExpense-SYNC] No ExpenseDocuments")
        return None

    except botocore.exceptions.ClientError as e:
        print(f"[AnalyzeExpense] ClientError: {e}")
        return None


FALLBACK_QUERIES = [
    {
        "Text": "What are taxes and tax amount applied?",
        "Alias": "TAXES"
    },
    {
        "Text":"What is the discount amount applied?",
        "Alias": "DISCOUNT"
    },
    {"Text": "What is the email address for the supplier/vendor?", "Alias": "VENDOR_EMAIL"},
    {
        "Text": "What is the vendor, seller, merchant, supplier, company, or issuer address?",
        "Alias": "VENDOR_ADDRESS"
    },
    {
        "Text": "What are the payment terms or due instructions, including phrases like Net 30, Net 45, due on receipt, remittance due immediately upon invoice, or when payment is due?",
        "Alias": "PAYMENT_TERMS"
    },
    {
        "Text": "What is the payment method or payee instruction used, including bank transfer, credit card, cheque/check, wire transfer, ACH, PayPal, or phrases like cheques payable to or checks payable to?",
        "Alias": "PAYMENT_METHOD"
    },
    {"Text": "What is the vendor name?", "Alias": "VENDOR_NAME"},
    {"Text": "What is the invoice number?", "Alias": "INVOICE_NO"},
    {"Text": "What is the invoice date?", "Alias": "INVOICE_DATE"},
    {"Text": "What is the due date?", "Alias": "DUE_DATE"},
    {"Text": "What is the total amount?", "Alias": "TOTAL"},
    {"Text": "What is the subtotal amount?", "Alias": "SUBTOTAL"},
    {"Text": "What is the tax amount?", "Alias": "TAX"},
    {"Text":"What is the tax code applied?","Alias":"TAX_CODE"},
    {"Text": "What is the currency?", "Alias": "CURRENCY"}

]



PAYMENT_QUERIES = [
    {"Text": "What is the bank name?", "Alias": "BANK_NAME"},
    {"Text": "What is the beneficiary name / account holder name / payee name?", "Alias": "BENEFICIARY_NAME"},
    {"Text": "What is the account number (Account No, A/C No, Acct No, Account #)?", "Alias": "ACCOUNT_NUMBER"},
    {"Text": "What is the IBAN (may appear as IBAN, I.B.A.N, ISBN, ISBIN, ISBAN, I8AN)?", "Alias": "IBAN"},
    {"Text": "What is the SWIFT or BIC code?", "Alias": "SWIFT_BIC"},
    {"Text": "What is the IFSC code (and MICR if present)?", "Alias": "IFSC_MICR"},
    {"Text": "What is the routing number / ABA or sort code?", "Alias": "ROUTING_SORT_CODE"},
    {"Text": "What is the payment reference / remittance reference?", "Alias": "PAYMENT_REFERENCE"},
    {"Text": "What is the remit-to / pay-to address?", "Alias": "REMIT_TO_ADDRESS"},
    {"Text": "What are the remittance instructions (Remit To / Please pay to / Payment instructions)?", "Alias": "REMITTANCE_INSTRUCTIONS"},
]



def run_analyze_document_all(bucket: str, key: str) -> Optional[Dict[str, Any]]:
    feature_types = ["QUERIES", "FORMS", "TABLES"]
    doc_spec = {"S3Object": {"Bucket": bucket, "Name": key}}
    all_queries = (FALLBACK_QUERIES + PAYMENT_QUERIES)[:15]

    try:
        if is_pdf(key) or key.lower().endswith((".tif", ".tiff")):
            print(f"[AnalyzeDocument-ASYNC] StartDocumentAnalysis for: s3://{bucket}/{key}")
            start_resp = textract.start_document_analysis(
                DocumentLocation=doc_spec,
                FeatureTypes=["FORMS", "TABLES", "QUERIES"],
                QueriesConfig={"Queries": all_queries}
            )
            job_id = start_resp["JobId"]
            print(f"[AnalyzeDocument-ASYNC] JobId: {job_id}")

            pages: List[Dict[str, Any]] = []
            max_tries = 30
            sleep_seconds = 1
            tries = 0

            while True:
                tries += 1
                resp = textract.get_document_analysis(JobId=job_id)
                status = resp.get("JobStatus")
                print(f"[AnalyzeDocument-ASYNC] JobStatus: {status}")

                if status in ("SUCCEEDED", "PARTIAL_SUCCESS"):
                    pages.append(resp)
                    break
                if status == "FAILED":
                    print(f"[AnalyzeDocument-ASYNC] Job failed: {resp}")
                    return None
                if tries >= max_tries:
                    print("[AnalyzeDocument-ASYNC] Max polling attempts reached, aborting.")
                    return None
                time.sleep(sleep_seconds)

            next_token = pages[0].get("NextToken")
            while next_token:
                resp = textract.get_document_analysis(JobId=job_id, NextToken=next_token)
                pages.append(resp)
                next_token = resp.get("NextToken")

            all_blocks: List[Dict[str, Any]] = []
            for p in pages:
                all_blocks.extend(p.get("Blocks", []))

            merged_resp = {
                "JobId": job_id,
                "Blocks": all_blocks,
                "DocumentMetadata": pages[0].get("DocumentMetadata"),
                "JobStatus": pages[-1].get("JobStatus"),
            }
            print(f"[AnalyzeDocument-ASYNC] Merged blocks: {len(all_blocks)}")

            print(
                "[RAW_DOCUMENT_ANALYZER_OUTPUT]",
                json.dumps(
                    merged_resp,
                    indent=2,
                    default=str
                )
            )

            # ✅ RUN QUERIES (SYNC) AND MERGE INTO merged_resp
            try:
                obj = s3.get_object(Bucket=bucket, Key=key)
                file_bytes = obj["Body"].read()

                query_resp = textract.analyze_document(
                    Document={"Bytes": file_bytes},
                    FeatureTypes=["QUERIES"],
                    QueriesConfig={"Queries": all_queries},
                )

                merged_resp["Blocks"].extend(query_resp.get("Blocks", []) or [])
                print(f"[AnalyzeDocument-QUERIES] Added blocks: {len(query_resp.get('Blocks', []) or [])}")
                print(f"[AnalyzeDocument-QUERIES] Final Blocks: {query_resp}")

            except botocore.exceptions.ClientError as qe:
                print(f"[AnalyzeDocument-QUERIES] ClientError: {qe}")

            return merged_resp

        # ---------------- NON-PDF SYNC PATH ----------------
        print(f"[AnalyzeDocument-SYNC] analyze_document for: s3://{bucket}/{key}")

        # ✅ Better to use BYTES here too (keeps queries consistent)
        obj = s3.get_object(Bucket=bucket, Key=key)
        file_bytes = obj["Body"].read()

        resp = textract.analyze_document(
            Document={"Bytes": file_bytes},
            FeatureTypes=feature_types,
            QueriesConfig={"Queries": all_queries},
        )
        print(f"[AnalyzeDocument-SYNC] Got Blocks: {len(resp['Blocks'])} Response formed : {resp}")
        return resp

    except botocore.exceptions.ClientError as e:
        print(f"[ASYNC ANALYZE DOCUMENT ERROR] Error : {e}")
        return None


EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)

def extract_query_answers(analyze_doc_resp: Dict[str, Any]) -> Dict[str, str]:
    blocks = analyze_doc_resp.get("Blocks", []) or []

    # Map QUERY_RESULT id → text
    result_text_by_id = {
        b["Id"]: (b.get("Text") or "")
        for b in blocks
        if b.get("BlockType") == "QUERY_RESULT" and b.get("Id")
    }

    answers: Dict[str, str] = {}

    print("\n========== QUERY EXTRACTION DEBUG ==========")

    for b in blocks:
        if b.get("BlockType") != "QUERY":
            continue

        query = b.get("Query") or {}
        alias = (query.get("Alias") or "").strip()
        qtext = (query.get("Text") or "").strip()

        print(f"\n[QUERY]")
        print(f"  Alias : {alias}")
        print(f"  Text  : {qtext}")

        if not alias:
            print("  -> SKIPPED (no alias)")
            continue

        relationships = b.get("Relationships") or []
        answer_ids = []

        for r in relationships:
            if r.get("Type") == "ANSWER":
                answer_ids.extend(r.get("Ids") or [])

        if not answer_ids:
            print("  -> NO ANSWER (no ANSWER relationship)")
            continue

        found_answer = False

        for rid in answer_ids:
            text = (result_text_by_id.get(rid) or "").strip()
            if text:
                answers[alias] = text
                found_answer = True
                print(f"  -> RESULT: {text!r}")
                break
            else:
                print(f"  -> ANSWER_ID {rid} has EMPTY text")

        if not found_answer:
            print("  -> ANSWER FOUND BUT EMPTY RESULT")

    print("===========================================\n")

    return answers


def normalize_email(text: str) -> Optional[str]:
    m = EMAIL_RE.search(text or "")
    return m.group(0) if m else None



# ---------------- ADJUSTMENT EXTRACTION ----------------

import re
from typing import Dict, List
from decimal import Decimal, InvalidOperation

ADJUSTMENT_KEYWORDS = {
    "tax": r"(tax|vat|gst|hst|pst|qst|igst|cgst|sgst|tva|iva)",
    "discount": r"(discount|disc|rebate)",
    "shipping": r"(shipping|freight|delivery)"
}

DATE_PATTERNS = [
    r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b",
    r"\b\d{4}-\d{2}-\d{2}\b",
    r"\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{1,2},?\s+\d{4}\b",
]

# Calculating the tax , discount and shipping from summary and line items
def extract_adjustments_from_rows(rows: List[str]) -> Dict[str, List[Dict[str, str]]]:
    """
    Extract tax, discount, shipping rows from reconstructed table rows.
    """

    adjustments = {
        "tax": [],
        "discount": [],
        "shipping": [],
        "due_date": [],
    }

    for row in rows:
        lower = row.lower()

        # TAX
        if re.search(r"\b(tax|gst|qst|vat|hst|pst|igst|cgst|sgst)\b", lower):
            matches = re.findall(r"\$?\d+\.\d{2}", row)
            if matches:
                adjustments["tax"].append({
                    "label": row,
                    "amount": matches[-1]
                })

        # DISCOUNT
        if re.search(r"\b(discount|disc|rebate)\b", lower):
            matches = re.findall(r"\$?\d+\.\d{2}", row)
            if matches:
                adjustments["discount"].append({
                    "label": row,
                    "amount": matches[-1]
                })

        # SHIPPING
        if re.search(r"\b(shipping|freight|delivery)\b", lower):
            matches = re.findall(r"\$?\d+\.\d{2}", row)
            if matches:
                adjustments["shipping"].append({
                    "label": row,
                    "amount": matches[-1]
                })

        # DUE DATE
        if re.search(r"\b(due date|payment due|due on|pay by|net due date|invoice due|amount due by|balance due by|payment due by)\b", lower):
            for pattern in DATE_PATTERNS:
                m = re.search(pattern, row, re.I)
                if m:
                    adjustments["due_date"].append({
                        "label": row,
                        "value": m.group(0)
                    })
                    break

    return adjustments


# ============================================================
# TABLE GRID CONSTRUCTION 
# ============================================================

def extract_rows_from_tables(blocks: List[Dict[str, Any]]) -> List[str]:
    block_map = {b["Id"]: b for b in blocks if "Id" in b}
    reconstructed_rows = []

    def get_cell_text(cell):
        parts = []
        for rel in cell.get("Relationships", []):
            if rel.get("Type") != "CHILD":
                continue

            for child_id in rel.get("Ids", []):
                child = block_map.get(child_id)
                if not child:
                    continue

                if child.get("BlockType") == "WORD":
                    parts.append(child.get("Text", ""))

                elif child.get("BlockType") == "SELECTION_ELEMENT":
                    if child.get("SelectionStatus") == "SELECTED":
                        parts.append("X")

        return " ".join(parts).strip()

    for table in [b for b in blocks if b.get("BlockType") == "TABLE"]:
        rows = {}

        for rel in table.get("Relationships", []):
            if rel.get("Type") != "CHILD":
                continue

            for child_id in rel.get("Ids", []):
                cell = block_map.get(child_id)
                if not cell or cell.get("BlockType") != "CELL":
                    continue

                row_index = cell.get("RowIndex")
                col_index = cell.get("ColumnIndex")

                rows.setdefault(row_index, {})[col_index] = get_cell_text(cell)

        for row_index in sorted(rows.keys()):
            row_text = " ".join(
                rows[row_index][col_index]
                for col_index in sorted(rows[row_index].keys())
                if rows[row_index][col_index]
            ).strip()

            if row_text:
                reconstructed_rows.append(row_text)

    print("[TABLE_ROWS]", json.dumps(reconstructed_rows, indent=2))
    return reconstructed_rows

def extract_payment_footer_from_lines(blocks):
    lines = [
        b.get("Text", "").strip()
        for b in blocks
        if b.get("BlockType") == "LINE" and b.get("Text")
    ]

    text = "\n".join(lines)
    lower = text.lower()

    payment_terms = ""
    payment_info = []

    for line in lines:
        l = line.lower()

        if re.search(r"(remittance due|due immediately|due upon invoice|due on receipt|payable upon receipt|net\s*\d+)", l):
            payment_terms = line

        if re.search(r"(cheques payable|checks payable|email payment transfer|email payment transfers|e-transfer|etransfer|payment transfer|wire transfer|ach|remit to|pay to|payable to)", l):
            payment_info.append(line)

    return {
        "PAYMENT_TERMS": payment_terms,
        "PAYMENT_INFO": "\n".join(payment_info)
    }


MONEY_RE = re.compile(r"\$?\d+(?:,\d{3})*(?:\.\d{2})")

SUMMARY_ROW_RE = re.compile(
    r"\b("
    r"sub[\s-]*total|subtotal|"
    r"total\s+for|grand\s+total|total\s+tax|total\s+taxes|"
    r"item\s+total|fees\s+total|"
    r"amount\s+due|balance\s+due|paid|outstanding|currency|"
    r"equipment\s+rental"
    r")\b",
    re.I
)

def to_decimal(value):
    if value is None:
        return Decimal("0.00")
    try:
        return Decimal(str(value).replace("$", "").replace(",", "").strip())
    except InvalidOperation:
        return Decimal("0.00")


def get_best_subtotal(summary):
    subtotals = []

    for key, value in summary.items():
        if key.startswith("SUBTOTAL"):
            amt = to_decimal(value)
            if amt > 0:
                subtotals.append(amt)

    if not subtotals:
        return Decimal("0.00")

    # Use the largest subtotal as true pre-tax subtotal.
    # Example: item total 6602, subtotal after fees 6698.
    return max(subtotals)


def recover_missing_line_items_from_rows(rows, existing_items, summary):
    existing_total = sum(to_decimal(i.get("PRICE")) for i in existing_items).quantize(Decimal("0.01"))

    expected_subtotal = get_best_subtotal(summary)
    missing_amount = (expected_subtotal - existing_total).quantize(Decimal("0.01"))

    # Narrow fallback: if subtotal logic says nothing is missing,
    # compare against page invoice TOTAL only.
    if missing_amount <= 0:
        invoice_total = to_decimal(summary.get("TOTAL")).quantize(Decimal("0.01"))
        total_gap = (invoice_total - existing_total).quantize(Decimal("0.01"))

        if total_gap > 0:
            missing_amount = total_gap
            expected_subtotal = invoice_total

    print("[RECOVERY_EXPECTED_SUBTOTAL]", str(expected_subtotal))
    print("[RECOVERY_EXISTING_ITEMS_TOTAL]", str(existing_total))
    print("[RECOVERY_MISSING_AMOUNT]", str(missing_amount))

    if missing_amount <= 0:
        return []

    recovered = []

    existing_amounts = {
        to_decimal(i.get("PRICE")).quantize(Decimal("0.01"))
        for i in existing_items
    }

    # First: recover from actual table/text rows if overhead row exists.
    for row in rows:
        row_clean = " ".join(row.split())
        lower = row_clean.lower()

        if not row_clean:
            continue

        amounts = MONEY_RE.findall(row_clean)
        if not amounts:
            continue

        row_amount = to_decimal(amounts[-1]).quantize(Decimal("0.01"))

        if SUMMARY_ROW_RE.search(lower):
            continue

        if row_amount in existing_amounts:
            continue

        if row_amount != missing_amount:
            continue

        recovered.append({
            "ITEM": row_clean,
            "QUANTITY": "1",
            "UNIT_PRICE": str(row_amount),
            "PRICE": str(row_amount),
            "EXPENSE_ROW": row_clean,
            "SOURCE": "TABLE_RECOVERY"
        })
        

    print("[RECOVERED_ITEMS]", json.dumps(recovered, indent=2))
    return recovered