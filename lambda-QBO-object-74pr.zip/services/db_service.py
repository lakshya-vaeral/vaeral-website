import boto3
from datetime import datetime, timezone

import logging
import pg8000 
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.client("dynamodb")
TABLE_NAME = "EmailAttachmentState"
PG_HOST = os.environ["PG_HOST"]
PG_PORT = int(os.environ.get("PG_PORT", "5432"))
PG_DATABASE = os.environ["PG_DATABASE"]
PG_USER = os.environ["PG_USER"]
PG_PASSWORD = os.environ["PG_PASSWORD"]


def _get_pg_connection():
    """
    pg8000 connection factory.
    """
    return pg8000.connect(
        host=PG_HOST,
        port=PG_PORT,
        database=PG_DATABASE,
        user=PG_USER,
        password=PG_PASSWORD,
        timeout=5,
    )

def _now_iso_z():
    # Returns timestamp like: 2025-11-21T07:43:52.418607Z
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def update_attachment_state(tracking_id: str, processed_s3_uri: str):
    """
    Called by attachment lambda after successfully writing extracted JSON.
    Only increments processed count + appends processed file info.
    """

    now_iso = _now_iso_z()
    print(f"[DDB] Updating attachment progress for uri={processed_s3_uri}")
    dynamodb.update_item(
        TableName=TABLE_NAME,
        Key={"id": {"S": tracking_id}},
        UpdateExpression="""
          SET processedAttachmentKeys =
                list_append(if_not_exists(processedAttachmentKeys, :emptyList), :newItem)
          ADD attachmentProcessedCount :one
        """,
        ExpressionAttributeValues={
            ":emptyList": {"L": []},
            ":newItem": {
                "L": [
                    {
                        "M": {
                            "key": {"S": processed_s3_uri},
                            "processedAt": {"S": now_iso}
                        }
                    }
                ]
            },
            ":one": {"N": "1"},
        },
    )

    print(f"[DDB] Updated attachment progress for trackingId={tracking_id}")

def insert_llm_response(
    tracking_id: str,  # this is actually message_processing_results.id
    tag: str,
    model: str,
    llm_input: str,
    llm_response: str,
):
    """
    Insert a new record into llm_responses table.

    First:
        - Check if message_processing_results row exists for given id
        - If exists, fetch its tracking_id (actual tracking id)
        - Use that tracking_id in llm_responses insert

    Returns True if insert succeeded, False otherwise.
    """

    conn = _get_pg_connection()
    try:
        cur = conn.cursor()

        # Fetch actual tracking_id from message_processing_results
        cur.execute(
            """
            SELECT tracking_id
            FROM public.message_processing_results
            WHERE id = %s::uuid;
            """,
            (tracking_id,),
        )

        result = cur.fetchone()

        if not result:
            logger.warning(
                "[PG] No message_processing_results found for id=%s",
                tracking_id,
            )
            cur.close()
            conn.close()
            return False

        actual_tracking_id = result[0]

        if not actual_tracking_id:
            logger.warning(
                "[PG] tracking_id is NULL for message_processing_results id=%s",
                tracking_id,
            )
            cur.close()
            conn.close()
            return False

        # 2️⃣ Insert into llm_responses using actual tracking_id
        cur.execute(
            """
            INSERT INTO llm_responses (
                tracking_id,
                tag,
                model,
                llm_input,
                llm_response
            )
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id;
            """,
            (actual_tracking_id, tag, model, llm_input, llm_response),
        )

        row = cur.fetchone()
        conn.commit()

        cur.close()
        conn.close()

        if row:
            logger.info(
                "[PG] Inserted llm_response id=%s tracking_id=%s",
                row[0],
                actual_tracking_id,
            )
            return True

        logger.warning(
            "[PG] Insert failed for tracking_id=%s",
            actual_tracking_id,
        )
        return False

    except Exception as e:
        try:
            conn.rollback()
        except Exception:
            pass

        logger.error(
            "[PG] Error inserting llm_response for message_processing_results id=%s: %s",
            tracking_id,
            e,
        )

        try:
            conn.close()
        except Exception:
            pass

        return False


