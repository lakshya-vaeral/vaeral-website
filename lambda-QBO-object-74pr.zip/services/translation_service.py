"""Translation service for lambda-QBO-object.

Detects the primary language of extracted Textract text and, if not English,
translates a whitelisted set of free-text fields to English before LLM processing.

The English and disabled paths return the input dict BY OBJECT IDENTITY (no-op).
This module NEVER raises to its callers.
"""
import copy
from typing import Optional

from config import (
    comprehend,
    translate,
    TRANSLATION_PROVIDER,
    TRANSLATE_TARGET_LANG,
    TRANSLATE_SOURCE_LANG,
)

# ---------------------------------------------------------------------------
# Translatable-fields whitelist (human-gate-1 approved, §2 of spec)
# ---------------------------------------------------------------------------

# Summary keys: translate values whose key starts with one of these prefixes.
# Prefix matching handles unique_key suffixes such as PAYMENT_INFO_2.
SUMMARY_TRANSLATABLE_PREFIXES: frozenset = frozenset({
    "PAYMENT_INFO",
    "PAYMENT_TERMS",
    "PAYMENT_METHOD",
    "REMITTANCE_INSTRUCTIONS",
    "REMIT_TO_ADDRESS",
    "VENDOR_ADDRESS",
    "NOTES",
    "DESCRIPTION",
    "OTHER",
})

# Item keys: translate values only when the key is an exact match.
ITEM_TRANSLATABLE_KEYS: frozenset = frozenset({
    "ITEM",
    "DESCRIPTION",
    "PRODUCT",
    "SERVICE",
})

# Maximum byte length of the text sample sent to Comprehend (AC-8).
_SAMPLE_MAX_BYTES = 3000


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _summary_key_is_translatable(key: str) -> bool:
    """True if key starts with any prefix in SUMMARY_TRANSLATABLE_PREFIXES."""
    for prefix in SUMMARY_TRANSLATABLE_PREFIXES:
        if key == prefix or key.startswith(prefix + "_"):
            return True
    return False


def _collect_sample(documents_json: dict) -> str:
    """Join whitelisted free-text from documents_json into a compact sample string.

    Caps the result to ~_SAMPLE_MAX_BYTES bytes so the Comprehend detect call
    stays bounded regardless of document size (AC-8).
    """
    parts = []
    for doc in documents_json.get("documents", []):
        for key, val in (doc.get("summary") or {}).items():
            if _summary_key_is_translatable(key) and isinstance(val, str) and val.strip():
                parts.append(val)
        for item in (doc.get("items") or []):
            for key, val in item.items():
                if key in ITEM_TRANSLATABLE_KEYS and isinstance(val, str) and val.strip():
                    parts.append(val)
    sample = " ".join(parts)
    # Truncate to byte limit (safe for Comprehend's 5000-byte limit)
    encoded = sample.encode("utf-8")[:_SAMPLE_MAX_BYTES]
    return encoded.decode("utf-8", errors="ignore")


def _translate_text(text: str, src: str, tgt: str) -> str:
    """Translate a single text string using AWS Translate.

    Returns the original text unchanged on empty input or any exception.
    """
    if not text or not text.strip():
        return text
    try:
        resp = translate.translate_text(
            Text=text,
            SourceLanguageCode=src,
            TargetLanguageCode=tgt,
        )
        return resp.get("TranslatedText", text)
    except Exception as exc:
        print(f"[TRANSLATION] _translate_text failed ({type(exc).__name__}): {exc}")
        raise  # re-raise so the outer try/except in translate_documents_to_english catches it


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def detect_primary_language(text: str) -> Optional[str]:
    """Return the ISO-639 code of the dominant language, or None.

    Returns None for empty/whitespace text, undetectable text, or any failure.
    NEVER raises.
    """
    if not text or not text.strip():
        return None
    try:
        resp = comprehend.detect_dominant_language(Text=text)
        languages = resp.get("Languages", [])
        if not languages:
            return None
        return languages[0].get("LanguageCode")
    except Exception as exc:
        print(f"[TRANSLATION] detect_primary_language failed ({type(exc).__name__}): {exc}")
        return None


def is_english(lang_code: Optional[str]) -> bool:
    """True iff lang_code is None or starts with 'en' (unknown -> treat as English -> skip)."""
    return lang_code is None or lang_code.startswith("en")


def translate_documents_to_english(documents_json: dict) -> dict:
    """Detect primary language and translate whitelisted free-text fields to English.

    English / disabled / failure paths return the input dict by object identity (no copy).
    Any failure falls back to the original documents_json — NEVER raises.
    """
    if TRANSLATION_PROVIDER != "aws":
        return documents_json

    try:
        sample = _collect_sample(documents_json)
        lang_code = detect_primary_language(sample)
        print(f"[TRANSLATION] detected_lang={lang_code!r} provider={TRANSLATION_PROVIDER!r}")

        if is_english(lang_code):
            print("[TRANSLATION] English or undetectable — skipping translation")
            return documents_json

        print(f"[TRANSLATION] Translating from {lang_code!r} -> {TRANSLATE_TARGET_LANG!r}")

        # Work on a deep copy so that any mid-translation failure leaves the
        # original documents_json fully intact (AC-6 no-partial-mutation guarantee).
        working = copy.deepcopy(documents_json)

        src = lang_code if TRANSLATE_SOURCE_LANG == "auto" else TRANSLATE_SOURCE_LANG
        tgt = TRANSLATE_TARGET_LANG

        for doc in working.get("documents", []):
            # Translate whitelisted summary fields
            summary = doc.get("summary") or {}
            for key in list(summary.keys()):
                if _summary_key_is_translatable(key):
                    val = summary[key]
                    if isinstance(val, str) and val.strip():
                        summary[key] = _translate_text(val, src, tgt)

            # Translate whitelisted item fields (never EXPENSE_ROW)
            for item in (doc.get("items") or []):
                for key in ITEM_TRANSLATABLE_KEYS:
                    val = item.get(key)
                    if isinstance(val, str) and val.strip():
                        item[key] = _translate_text(val, src, tgt)

            # adjustments block: left verbatim (§2)

        return working

    except Exception as exc:
        print(f"[TRANSLATION] translate_documents_to_english failed, falling back: {exc}")
        return documents_json
