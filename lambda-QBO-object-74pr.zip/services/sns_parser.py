from typing import List, Dict
import json
import re
from urllib.parse import unquote_plus


def parse_sns_event(event) -> List[Dict[str, str]]:
    """
    Returns list of dicts with {bucket, key} for each S3 object referenced.
    Supports:
      - SQS -> SNS -> S3 event
      - SNS -> S3 event
      - Direct S3 trigger
    """
    print("Executing parse_sns_event ..")
    results: List[Dict[str, str]] = []

    def _process_s3_record(bucket: str, key: str):
        """Apply your existing email/<id>/<filename> + skip-json logic."""
        if not bucket or not key:
            return

        print(f"Received S3 event for key: {key}")

        # 1) Only process keys of the form: <id>/[email/attachments]/input/atch.pdf
        m = re.match(r"^([^/]+)/attachments/input/([^/]+)$", key)
        if not m:
            print(f"Skipping key (not a direct attachment under email/<id>): {key}")
            return

        email_id, filename = m.groups()

        # 2) Skip JSON files (these are outputs/metadata, not attachments)
        if filename.lower().endswith(".json"):
            print(f"Skipping key (JSON file, not an attachment): {key}")
            return

        results.append({"bucket": bucket, "key": unquote_plus(key)})

    for rec in event.get("Records", []):
        source = rec.get("EventSource") or rec.get("eventSource")

        # Case 0: Lambda triggered by SQS, which carries an SNS notification, which carries an S3 event
        if source == "aws:sqs":
            print("Processing SQS-wrapped SNS/S3 event")
            body_str = rec.get("body", "")

            try:
                sns_envelope = json.loads(body_str)
            except json.JSONDecodeError:
                sns_envelope = json.loads(body_str.encode("utf-8").decode("unicode_escape"))

            msg_str = sns_envelope.get("Message", "")
            try:
                s3_event = json.loads(msg_str)
            except json.JSONDecodeError:
                s3_event = json.loads(msg_str.encode("utf-8").decode("unicode_escape"))

            for s3rec in s3_event.get("Records", []):
                s3info = s3rec.get("s3", {})
                bucket = s3info.get("bucket", {}).get("name")
                key = s3info.get("object", {}).get("key")
                _process_s3_record(bucket, key)

            continue

        # Case 1: Lambda triggered directly by SNS (old flow)
        if source == "aws:sns":
            print("Processing direct SNS/S3 event")
            msg_str = rec["Sns"]["Message"]
            try:
                msg = json.loads(msg_str)
            except json.JSONDecodeError:
                msg = json.loads(msg_str.encode("utf-8").decode("unicode_escape"))

            for s3rec in msg.get("Records", []):
                s3info = s3rec.get("s3", {})
                bucket = s3info.get("bucket", {}).get("name")
                key = s3info.get("object", {}).get("key")
                _process_s3_record(bucket, key)

            continue

        # Case 2: Lambda triggered directly by S3 (no SNS/SQS)
        if source == "aws:s3":
            print("Processing direct S3 event")
            s3info = rec.get("s3", {})
            bucket = s3info.get("bucket", {}).get("name")
            key = s3info.get("object", {}).get("key")
            _process_s3_record(bucket, key)

    return results
